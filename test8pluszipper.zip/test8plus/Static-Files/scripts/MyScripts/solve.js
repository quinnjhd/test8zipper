var solve1 = document.getElementById("fun");
var xApp = document.getElementById("x->");
let answer1s = document.getElementById("try");
let answer2s = document.getElementById("try1");
var answerLaTeX = document.getElementById("answerLaTeX");
var solveButton = document.getElementById("solve");
var coolAnswer = document.getElementById("Answer");

function lcSolve(){
    
    console.log("FUN23")
    

    var ansText = nerdamer(solve1.value).sub('x',"("+(xApp.value)+")").toString();
    var ansText2 = ansText;
    var numerator = nerdamer(ansText).numerator().toString();
    var denominator = nerdamer(ansText).denominator().toString();

    ansText = numerator + "/" + denominator;

    answer1s.textContent = ansText;
    // answer2s.textContent = ansText2;

    var tree2 = MathLex.parse(ansText)
    latex = MathLex.render(tree2, 'latex');
    latex = latex.replace(/\\,/g,"");
    answerLaTeX.textContent = "$${" + latex +"}$$";
    coolAnswer.textContent = answer;
    MathJax.Hub.Queue(["Typeset",MathJax.Hub]); 

}