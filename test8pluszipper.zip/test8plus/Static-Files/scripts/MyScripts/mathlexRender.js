
var fun1 = document.getElementById('fun');
var fun1b = document.getElementById('x->');
var botmstr = "\\lim \\limits_{x \\to }";
var latexPlace = "";

fun1.addEventListener('input', updateValueMain);
fun1b.addEventListener('input', updateValueMain);

function updateValueMain(e){

if (e.srcElement === fun1){

var temp1a = e.srcElement.value;
var tree = MathLex.parse(temp1a)
latex = MathLex.render(tree, 'latex');
latex=latex.replace(/\\,/g,"");
latexPlace = latex;
//console.log(latexPlace);
document.getElementById("math-display").textContent = "$${ " + botmstr + " " + latexPlace + "}$$";   
MathJax.Hub.Queue(["Typeset",MathJax.Hub]); 

}

else{
var xApproches = e.srcElement.value;
var xApprochesTree = MathLex.parse(xApproches)
latex1b = MathLex.render(xApprochesTree, 'latex');
botmstr = botmstr.substring(0,20) + latex1b + " }";
//botmstr = botmstr.replace()
document.getElementById("math-display").textContent = "$${ "+ botmstr +" "+latexPlace+" }$$";
console.log(botmstr);
MathJax.Hub.Queue(["Typeset",MathJax.Hub]); 
}

}





