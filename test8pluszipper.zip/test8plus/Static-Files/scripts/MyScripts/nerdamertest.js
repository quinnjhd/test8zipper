//var e = nerdamer("((1/(x-2)-1/2)/x)")

//alert(e.numerator().toString());