var target = document.getElementById('var');
var tgxout = document.getElementById('math-display');
var tgxin = document.getElementById('x->in');

target.addEventListener('input', updateBotstr);

function updateBotstr(e){

var temp = e.srcElement.value;


if ((temp === '')||(temp.match(/[a-z]/)===null)){
     temp = 'x';
}

document.getElementById("math-display").textContent = "$${ " + botmstr + " " + latexPlace + "}$$"; 
tgxout.textContent = tgxout.textContent.replace("x \\to", temp+"\\to");
tgxin.textContent = "\\({ " + temp + " \\!\\to}\\)";
MathJax.Hub.Queue(["Typeset",MathJax.Hub]); 

}


