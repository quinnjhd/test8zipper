/* var stepsButtonHTML = document.getElementById('stepsbutton');
var stepsHTML = document.getElementsByClassName('Steps');

// THIS SCRIPT HAS NO AFFECT AS FAR AS I CAN TELL SO FAR
// stepsButtonHTML.addEventListener('click',showsteps);

showsteps();

function showsteps(){

    console.log("L")
//console.log("hello ", stepsHTML.textContent.substring(stepsHTML.textContent.indexOf("$$")+2,   stepsHTML.textContent.lastIndexOf("$$")   ));

console.log(stepsHTML.length)
console.log(stepsHTML[0].textContent)
console.log(stepsHTML[1].textContent)

for (var i=0; i < stepsHTML.length; i++){
try{
var trys = ["end step: ","Algebrite Simplify: "]
console.log('hello')
var based = stepsHTML[i].textContent.substring(stepsHTML[i].textContent.indexOf("$$")+2, stepsHTML[i].textContent.lastIndexOf("$$")); 
console.log('based:',based)
var tree = MathLex.parse(based)
latexsteps = MathLex.render(tree, 'latex');
latexsteps=latexsteps.replace(/\\,/g,"");
latexPlace = latexsteps;
// console.log("Ljedfijdsfs", latexPlace);
stepsHTML[i].textContent = trys[i] + "$${ " + latexPlace + "}$$";   
MathJax.Hub.Queue(["Typeset",MathJax.Hub]);
}
catch{
    console.log('error on', stepsHTML[i].textContent)
}

//stepsHTML.style.color = 'visible';

}
}

*/