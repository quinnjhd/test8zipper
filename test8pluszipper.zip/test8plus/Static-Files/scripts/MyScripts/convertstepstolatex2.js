
var winner = document.getElementById('steps1button');
var simplified = document.getElementById('Simplified');
var latexPlace2 = "";






winner.addEventListener('click', run2);
 

function run2(){

    console.log("FUN2");
    var temp1a3 = simplified.textContent.replace("$$","").replace("Algebrite simplify: ","");
    console.log(temp1a3)
    var tree3 = MathLex.parse(simplified.textContent.replace("$$","").replace("Algebrite simplify: ",""))
    latex3 = MathLex.render(tree3, 'latex');
    latex3=latex3.replace(/\\,/g,"");
    latexPlace3 = latex3;
    //console.log(latexPlace);
    simplified.textContent = "$${ " + latexPlace3 + "}$$";   
    MathJax.Hub.Queue(["Typeset",MathJax.Hub]); 

}

//console.log("L");
//app3();


//function app3(){
//visibility
/*
var temp1a3 = simplified.textContent;
var tree3 = MathLex.parse(temp1a3)
latex3 = MathLex.render(tree3, 'latex');
latex3=latex3.replace(/\\,/g,"");
latexPlace3 = latex3;
//console.log(latexPlace);
simplified.textContent = "$${ " + latexPlace3 + "}$$";   
MathJax.Hub.Queue(["Typeset",MathJax.Hub]); 
*/
//}


//var xApproches = e.srcElement.value;
//var xApprochesTree = MathLex.parse(xApproches)
//latex1b = MathLex.render(xApprochesTree, 'latex');
//botmstr = botmstr.substring(0,20) + latex1b + " }";
//botmstr = botmstr.replace()
//document.getElementById("math-display").textContent = "$${ "+ botmstr +" "+latexPlace+" }$$";
//console.log(botmstr);
//MathJax.Hub.Queue(["Typeset",MathJax.Hub]); 








