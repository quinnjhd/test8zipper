var fun1 = document.getElementById('fun');
var ider= document.querySelector('#identifer');
var click = document.getElementById('inp');
var expression;


console.log("reak")



fun1.addEventListener('input', idermain);
//click.addEventListener('submit', id);

function idermain(e){

    expression = e.srcElement.value;
    //console.log("e",expression);
    //console.log("e2",nerdamer(expression).numerator().toString());
    //console.log("LLL",nerdamer(expression).numerator().toString().includes("^(-"));
    if(nerdamer(expression).numerator().toString().includes("^(-")){
        console.log("YESNum");
        ider.setAttribute("value", "cd");
    }
    else if(nerdamer(expression).numerator().toString().includes("^(-")){
        console.log("YESDem");
        ider.setAttribute("value", "cd");
    }
    else if(expression.vaue = ""){ //place holder

    }
    else{
        console.log("NONONONO");
        ider.setAttribute("value", "unsolvable");
    }
}

