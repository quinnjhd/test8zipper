// Built in Packedges
const fs = require('fs');
const path = require('path');
// Third Party Packedges
const Algebrite = require('algebrite');
var shell = require('shelljs');
const express = require('express');
const bodyParser = require('body-parser');
var AWS = require('aws-sdk');
AWS.config.region = process.env.REGION;
const perf = require('execution-time')();

var qertest = 0;

var numreq = 0;
var goesToside = "";
var justStarted = true;
var justPost = false;
var resetside = false; 
var slvEx = "";
var slvXgo = "";
var slvVar = "";
var slvSide = "";
//var answer;
var reqLim = "";
//var fun;
//var fun2;
var ren = false;
var funFinal = 5000;
var firstPost = false;
var q1;
var newx;

//console.log(justStarted);

//if (justStarted){
//var exec = require('child_process').exec;
//exec('.\\maxima-5.42.2\\bin\\maxima.bat', function callback(error, stdout, stderr){
//});// cmd /c start "" cmd /c 
// ^ put in exec string to run on windows

//var robot = require("kbm-robot");

//robot.startJar("7");
//robot.sleep(175)
//.mouseMove(200, 100)
// timetowaitbeforemovingmouse = 175 (from 5000)
//justStarted = false;
//}

if (firstPost){
    funFinal = 175;
}

const app = express();
require('./prod')(app);
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
//app.set('views', path.join(__dirname, 'views'));
//app.engine('html', require('ejs').renderFile);
//app.set('view engine', 'html');
var urlencodedParser = bodyParser.urlencoded({extended: false});

app.use(express.static('./Static-Files'));

app.get('/', (req, res) => {

   // const p = new Promise((resolve, reject)=>{
  //      if (justPost === true){
   // setTimeout(()=>
  //  fs.readFile('./maxima-5.42.2/test.txt', (err, data)=>{
  //  console.log("read file");
  ///  if (err){console.log(err);}
  //  else{
        
     //   fun = data.toString(); // could just use only one variable (fun or fun2) and replace one with the other.
     //   fun2 = fun.substring(0,fun.lastIndexOf("$$"));
      //  fun2 = fun2.replace("$$", '');
      //  console.log(fun);
       // console.log(fun2);

      //  resolve("$$"+fun2+"$$");
    //}
//}),15000);}}); // dont forget to make the time a variable based off what the length of the input is. 
    
if (justPost === false){
    slvEx = '';
    slvXgo = '';
    slvSide = 'two-sided';
    resetside = true;
}else{ 
numreq--;
ren = true;
justPost=false;
resetside=false;
}
//if (ren === true){
res.render(path.join(__dirname, './Static-Files/html/index.html'), {an: "s", s1: null,simplified: null, s2: null, s3: null, s3: null, s4: null, s5: null, s6: null, q: null});
//ren = false;
//}
//else{
//res.render(path.join(__dirname, './Static-Files/html/index.html'), {ex: slvEx, xg: slvXgo, vr: slvVar, sd: slvSide, rs: resetside, an: null});
//}
//res.render(path.join(__dirname, '../Static-Files/html/index.html'), {ex: answer });
//res.sendFile('index.html', {root: path.join(__dirname, '../Static-Files/html')});
//res.render('index.html');
//console.log(path.join(__dirname, '../Static-Files/html');


});

app.post('/', urlencodedParser,(req, res, next) => {
    perf.start();
console.log("req.body",req.body);  
firstPost = true;
justPost = true;
// console.log(req.body.input);
// console.log("s");
//res.render(path.join(__dirname, '../Static-Files/html/index.html'));
//setTimeout(function() {   
slvEx = req.body.Expression;
slvXgo = req.body.xgoes;
slvVar = req.body.var; // DONT EVEN USE THESE?? GOOD THING BTW.
slvSide = req.body.side;
//}, 5000);
//q1 = parseInt(req.body.epic, 10) + q;
//reqLim = `'f(x):= limit(${req.body.Expression}, ${req.body.var}, ${req.body.xgoes});`
//setTimeout(function() {
/// reqLim inside ".typeString" to make it go faster (maybe)
if (req.body.side === 'two-sided'){
    goesToside = ''
    //reqLim = `'f(x):= limit(${req.body.Expression}, ${req.body.var}, ${req.body.xgoes});`;
}else if (req.body.side === '-'){
    goesToside = ',minus'
   // reqLim = `'f(x):= limit(${req.body.Expression}, ${req.body.var}, ${req.body.xgoes},minus);`;
}else if (req.body.side === '+'){
    goesToside = ',plus'
   // reqLim = `'f(x):= limit(${req.body.Expression}, ${req.body.var}, ${req.body.xgoes},plus);`;    
}

//setTimeout(() => {
    fs.writeFile(`${JSON.stringify(req.body).replace(/\//g,'').replace(/"/g,'').replace(/:/g,'').replace(/{/g,'').replace(/}/g,'').replace(/ /g,'').replace(/,/g,'').replace(/\)/g,'').replace(/\(/g,'').replace(/\*/g,'').replace(/^/g,'')}.txt`, "",function(error){
        if(error)throw error;
        //setTimeout(() => {
        shell.exec(`maxima -q --batch-string 'f(x):= limit(${req.body.Expression}, ${req.body.var}, ${req.body.xgoes}); with_stdout ("${JSON.stringify(req.body).replace(/\//g,'').replace(/"/g,'').replace(/:/g,'').replace(/{/g,'').replace(/}/g,'').replace(/ /g,'').replace(/,/g,'').replace(/\)/g,'').replace(/\(/g,'').replace(/\*/g,'').replace(/^/g,'')}.txt", print(tex(f(x))))$' `,cool2());
    //}, 5000);
    });  
//}, 5000);

//hexString = q.toString(16);
//setTimeout(function(){
//},5000);

 function dog (answer){
    //console.log(a);
    //setTimeout(() => {
        fs.unlink(`${JSON.stringify(req.body).replace(/\//g,'').replace(/"/g,'').replace(/:/g,'').replace(/{/g,'').replace(/}/g,'').replace(/ /g,'').replace(/,/g,'').replace(/\)/g,'').replace(/\(/g,'').replace(/\*/g,'').replace(/^/g,'')}.txt`,(err, data)=>{

            
            
             var x = Algebrite.run(`${req.body.Expression}`).toString();  //CONTROL SHIFT F12 TO SEE VARIABLES
             console.log("algebrite run:", x);
            //var ? = Algebrite.run(`${req.body.Expression}`).toString(); <- THESE WILL BE STEPS
            //var ? = Algebrite.run(`${req.body.Expression}`).toString();
            // STEPS START HERE
             var simplified = 1;
            
             // try{
                simplified = Algebrite.simplify(`${req.body.Expression}`).toString()
             // }
             // catch{}
            
            
             console.log("algebrite simplify:", simplified, typeof simplified);
            
            
            //console.log("algebrite simplify:", simplified);

             try{
                console.log(`"L2",${req.body.Expression}`)
             x = Algebrite.eval(`subst(${req.body.xgoes},${req.body.var},${req.body.Expression})`).toString();
            // put "plug in method" here
             console.log("plug in method")
             }
             catch{
                
             console.log("not plug in method")
            //if !(ln, trig, etc...){
             console.log(`"L2-2",${req.body.Expression}`)
            //x = "$$"+Algebrite.simplify(`${req.body.Expression}`).toString()+"$$";

            //console.log("algebrite simplify:", x);

             }
            //else{ // do trig shit etc
            //}

            //try{
               // x = "$$"+Algebrite.eval(`subst(${req.body.xgoes},${req.body.var},${x})`).toString()+"$$";
               // console.log("expand, factor, or common denominator method")
            //}
           // catch{
            //    console.log("not expand, factor, or common denominator method")
            //    console.log("conjugate or substitution method")
                //if (req.body.expression.includes("sqrt(")){
                    //console.log("conjugate method")
                //}
                //else{
                //    console.log("substitition method")
                //}
           // }

            //}

            //try{
            //x = Algebrite.eval(`subst(${req.body.xgoes},${req.body.var},${req.body.Expression})`).toString();
            //}
            //catch{
            //    console.log('EPIC R')
            //}

            console.log("epicnew", simplified)

            res.render(path.join(__dirname, './Static-Files/html/index.html'), {an: answer, simplified: simplified, s1: null, s2: null, s3: null, s3: null, s4: null, s5: null, s6: null, q: qertest}); 
                                                                                              // FUTHER FUTURE 2019/09/19: 
                                                                                              //
                                                                                              // Use 'expecting key after _' error in front end (maybe in other file in win desktop) to add an expecting like 
                                                                                              // mathjax display, insted of JUST saying, for example, if input is x+ error:'expecting key after +' 
                                                                                              // display: error message AND x + _ (box or underscore, or nothing)
                                                                                              //
                                                                                              // can render with req.body.expression ect.. to keep inputed values where they were. 
                                                                                              // use history.back() (front end js/html) in a form with a input onclick function and when user 
                                                                                              // hits back button (maybe) to handle user going back in calculating history (have to make it go
                                                                                              // back twice) if cant run function on back button press, try and run func on any refresh (maybe
                                                                                              // use vue) and clear all inputs and outputs on any refresh/backpress (might not be possible when 
                                                                                              // res.render intsed of res.send or res.refresh). Further test timeout on all aspects of code.
                                                                                              // refresh issue: after computing if refresh is hit, it doesn't work, but if hit after back 
                                                                                              // button, it does, semi-expected because we used res.render alone, insted of res.refresh->res.render.
                                                                                              //
                                                                                              // Can delete all global variables.
                                                                                              //
                                                                                              // *i think res.send does not allow variable transfer to frontend.
            //res.redirect(303, '/');
                         //res.render(path.join(__dirname, './Static-Files/html/index.html'), {ex: slvEx, xg: slvXgo, vr: slvVar, sd: slvSide, rs: resetside, an: answer});
        });
    //}, 5000);
};

function cool (callback){
    //setTimeout(() => {
    //console.log(typeof req.body);
    //setTimeout(function(){   
        
fs.readFile(`${JSON.stringify(req.body).replace(/\//g,'').replace(/"/g,'').replace(/:/g,'').replace(/{/g,'').replace(/}/g,'').replace(/ /g,'').replace(/,/g,'').replace(/\)/g,'').replace(/\(/g,'').replace(/\*/g,'').replace(/^/g,'')}.txt`, (err, data)=>{
     //console.log("read file");
     
      if (err){console.log(err);}
        //callback();}
      else{
        const results = perf.stop();
        //console.log(results.time);
        //setTimeout(() => {
        
          var t = 0;
          var fun = data.toString(); // could just use only one variable (fun or fun2) and replace one with the other.
          var fun2 = fun.substring(0,fun.lastIndexOf("$$"));
          fun2 = fun2.replace("$$", '');
          //console.log(fun);
          //console.log(fun2);
          var answer = "$$"+fun2+"$$";
          callback(answer);  
        

          //setTimeout(() => {
            //res.redirect(303, '/');   
          //}, 5000);
        //}, 5000);
          //if (callback){
        
          //}
      }
          
});
//}, 5000);   
//}, 5000);
};

function cool2(){
    //setTimeout(function() {   
        cool(dog);
    //}, 5000);
}


//setTimeout(function(){ console.log("new "+answer);
 //}, 1);


// console.log("try"+answer);
    
});





//console.log(ansEPIC);
//res.json(res.jsonBody.Expression);

//res.end();
//next();




app.get('/test', (req, res) => {

//var exec = require('child_process').exec;
//exec('cmd /c start "" cmd /c C:\\maxima-5.42.2\\bin\\maxima.bat', function callback(error, stdout, stderr){
//});

//res.render(path.join('index1.html'), {Expression: req.body.Expression});
//res.sendFile('index.html', {root: path.join(__dirname, '../Static-Files/html')});


    });



app.listen(8080, ()=> console.log("fun2"));


// WHERE YOU LEFT OFF: completed: displaying answer, see plans
//
//
// note: changed name of program to "name" from "Dynamic-Files", did it to fix
// "file contains emphasized items side popup", probably doesn't matter. Also
// changes packedge-lock.json file "Dynamic-Files" name at top with "name" to
// match the packedge.json file.
//
// plans in order: 
//
// (DONE) set up calc with filereader and make core work (no steps or css yet)
// 
// skip ahead to "setup with vps" step if bored of coding, 
// this entails watching "deployment section of mosh course"
//
// fix when submit button clicked mathjax display resets 
//
// make timeinterval time a variable based off of how long the input is
//
// watch some of course that may be useful
// definatly look at "deployment"
//
// then setup and test with paid vps
//
// setup with test domain and test with multiple requests
// test domain: testdomain72362.com
//
// store request in backend untill other request is finished. 
// maybe use "express-queue" node packedge
// (07-29): also use it as middleware that is passed throgh the 'next' parameter only when posing 
// stuff to server. Other solution, catch kbm error and when catched send input to database or 
// queue of sorts in backend then solve input later.
// Reason: Make it so kbm bot has already started error does not come, 
// Backup: if error persists give a "too many requests, please try again" error to user
//
// in front end handle no input or incorrect input so POST is not called without 
// proper calculation. One way is by controlling the buttons "type" in css or 
// front end js.  or front end js. For example if input is not valid make button
// unpressable or the other option is if it is pressed, dont post.
//
// in front end if limit can be solved just by subsistuting or 
//
// add steps
//
// try (if needed) to replace the timeout on the readfile so it activates right after the
// commands have been inputed.
//
// add front end design
//
// restructure app, look at course
//
// watch some of course that may be useful
// definatly look at "deployment" section
// if havent already
//
// delete nodemon!
//